import download from './download.png';
import logo from './logo.svg';
import preview from './preview.png';

export {
  download,
  logo,
  preview,
};
